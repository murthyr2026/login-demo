# Login screen starter

A responsive login-screen demo in one `index.html` file. It includes the HTML,
CSS, and JavaScript, so no installation, build tools, or server are needed.

**This is a learning/demo screen, not real authentication.** The sample passwords
are visible in the source code, and the welcome screen can be revealed without
logging in. Do not use real passwords or place private data in this page.

## 1. Run it on your computer

1. Extract `login-screen-starter.zip`, or download `index.html` directly.
2. Double-click `index.html` to open it in a browser. If it opens in a text
   editor instead, right-click it and choose **Open with** your browser.
3. Enter one of the account pairs below and select **Sign in**.

| User ID | Password |
| --- | --- |
| User1 | PW1 |
| User2 | PW2 |
| User3 | PW3 |

Both fields are case-sensitive: `User1` and `PW1` work together; `user1` or
`pw1` do not. Extra spaces around the User ID are ignored. Spaces in passwords
are preserved.

The page provides required-field validation, a Show/Hide password button, an
error for incorrect credentials, a welcome screen, and a Sign out button.
Refreshing returns to the login screen. It does not create a persistent session.

## 2. Upload to GitHub using your browser

A repository is a project folder on GitHub that keeps a history of changes.

1. Sign into GitHub, then open <https://github.com/new>.
2. Use your personal account as the owner and name the repository `login-demo`.
3. Choose the repository visibility you want. Choose **Public** if you want the
   optional GitHub Pages site on GitHub Free. The files will be visible to everyone.
4. Enable **Add README**, then select **Create repository**.
5. In the new repository, select **Add file > Upload files**.
6. Upload `index.html` from this starter. Place the file directly at the top
   level of the repository. Do not upload the ZIP as the website, and do not
   put `index.html` inside an extra folder.
7. Enter the commit message `Add login screen`.
8. For this new personal demo, choose to commit directly to the `main` branch,
   then select **Commit changes**. A commit saves a version of your changes.

You can also upload this `README.md` if you want these instructions to replace
the starter README GitHub generated. Only `index.html` is needed to run the demo.

GitHub stores the code at this point. Opening the file on github.com displays
its source. The next section gives you a working website address.

Official instructions:

- [Create a repository](https://docs.github.com/en/get-started/start-your-journey/creating-a-repository-for-your-project-on-github)
- [Upload existing files](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)

## 3. Optional: publish the demo with GitHub Pages

1. In the repository, open **Settings > Pages**.
2. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
3. Choose the **main** branch and the **/(root)** folder, then select **Save**.
4. After deployment finishes, return to **Settings > Pages** and choose
   **Visit site**. GitHub says publication can take up to 10 minutes.

For a repository called `login-demo`, the usual website address is:

```text
https://YOUR-GITHUB-USERNAME.github.io/login-demo/
```

Replace `YOUR-GITHUB-USERNAME` with your actual GitHub username. The repository
name is the last part of the address. The address shown in Pages settings is
the authoritative link for your site.

GitHub Free supports Pages for public repositories. Eligible paid plans also
support private source repositories; a private source repository alone does
not make its published website private. This demo does not restrict access.

If you see a 404, confirm that the file is named exactly `index.html` (not
`index.html.txt`), is at the repository's top level, and that Pages uses
`main` and `/(root)`. Check the repository's **Actions** tab for deployment status.

Official instructions:

- [Configure the publishing source](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)
- [Create and view a Pages site](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)
- [About GitHub Pages and project URLs](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)

## 4. Add another demo account

Open `index.html` in a plain-text editor and find `const users = new Map`.
Replace that block with:

```javascript
const users = new Map([
  ["User1", "PW1"],
  ["User2", "PW2"],
  ["User3", "PW3"],
  ["User4", "PW4"]
]);
```

Save the file and refresh the browser. You can now sign in as `User4` with `PW4`.

To also show the new account under **Try a demo account**, add this row after
the existing User3 row in the table's `<tbody>` section:

```html
<tr><td>User4</td><td>PW4</td></tr>
```

The first value is the User ID; the second is its password. Keep the quotes,
square brackets, and commas. Use only made-up sample passwords here.

To update GitHub after a local edit, upload the revised `index.html` to the
same repository location and commit the change. If Pages is enabled, changes
to the selected branch are published automatically.

## 5. Customize the screen

- Change `Welcome back.` to your preferred heading.
- Change `#3857cb` in the CSS to customize the main accent color; maintain
  readable text and visible focus outlines.
- Add demo content inside the section with `id="welcome-screen"`.
- To inspect or copy the code, open `index.html` in a plain-text/code editor.
  Use a plain-text file, not a Word document; keep the `.html` extension.

## Before using real accounts

Real authentication needs a backend or authentication service that verifies
users, stores password hashes securely, manages sessions, and checks access
to protected resources on the server. Changing the sample passwords or hiding
the demo-account table does not secure this browser-only example.

GitHub Pages hosts static HTML, CSS, and JavaScript; it cannot run an
authentication backend itself. You can keep a frontend on Pages and connect
it to a separately hosted backend or authentication service.

Further reading:

- [OWASP authentication guidance](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html)
- [OWASP authorization guidance](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html)

## Verification

The embedded JavaScript was checked in Node with a simulated page for all
three successful sign-ins, incorrect credentials, case sensitivity, password
visibility, sign-out, error clearing, and focus targets. The HTML and CSS were
reviewed. Browser rendering and native form behavior could not be tested in
the build environment; try the file in your browser before publishing.
